package com.cognizant.truYum.dao;

public class MenuItemDaoCollectionImpl {

}
