package com.cognizant.truYum1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruYum1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
